/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package design.clases;

/**
 *
 * @author julio.nava
 */
public enum EClasificacion {
    A,
    B,
    B15,
    C,
    R
}
